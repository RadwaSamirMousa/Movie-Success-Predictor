from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
import pickle

def SVM (X, y):

 print("\n\n--------------------------SVM------------------------\n\n")
 classifier= SVC()
 classifier.fit(X, y)
 pred= classifier.predict(X)
 print('Training accuracy is', round(classifier.score(X, y)*100), '%')
 filename = 'finalized_model.sav'
 pickle.dump(classifier, open(filename, 'wb'))

 return  classifier