import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn import metrics
import pickle

def knn (X_train,y_train):
 print("\n\n---------------------KNN-----------------------\n\n")
 error = []
 knn = ' '
 pred_i = ' '
# Calculating error for K values between 1 and 40
 for i in range(1, 40):
    knn = KNeighborsClassifier(n_neighbors=i)
    knn.fit(X_train, y_train)
    pred_i = knn.predict(X_train)
    error.append(np.mean(pred_i != y_train))
 print("Training accuracy: ", (knn.score(X_train, y_train) * 100), "%")

 plt.figure(figsize=(12, 6))
 plt.plot(range(1, 40), error, color='red', linestyle='dashed', marker='o',
         markerfacecolor='blue', markersize=10)
 plt.title('Error Rate K Value')
 plt.xlabel('K Value')
 plt.ylabel('Mean Error')
 plt.show()

 filename = 'Knn_model.sav'
 pickle.dump(knn, open(filename, 'wb'))

 return  knn