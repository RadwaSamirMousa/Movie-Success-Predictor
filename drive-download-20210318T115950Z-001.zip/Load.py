import pickle

def load():
 x_test = ' '
 y_test = ' '
 loaded_model = pickle.load(open('Knn_model.sav', 'rb'))
 result = loaded_model.score(x_test, y_test)*100
 print(result,'%')
