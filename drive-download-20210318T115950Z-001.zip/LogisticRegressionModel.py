from sklearn.linear_model import LogisticRegression
import numpy as np
import pickle


def logistic_regression(x_train,y_train):


    print("\n\n----------------------Logistic Regression----------------------\n\n")

    logistic = LogisticRegression(solver='lbfgs', max_iter=1000)
    logistic.fit(x_train, y_train)
    pred_train = logistic.predict(x_train)
    print("Training accuracy: ", (logistic.score(x_train, y_train) * 100), "%")
    filename = 'Logestic_model.sav'
    pickle.dump(logistic, open(filename, 'wb'))

    return  logistic